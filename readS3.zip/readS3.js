var AWS = require('aws-sdk');
var s3 = new AWS.S3();

exports.handler = (event, context, callback) => {
    
    var bucket = event.bucket;
    var key = event.key;
    s3.getObject({"Bucket":bucket, "Key":key}, function(err,data){
        if(err){
            console.log(err)
            return;
        }
        
        callback(null, parseInt(data.Body));
    });
    
};