var aws = require('aws-sdk');
var lambda = new aws.Lambda({region: 'us-east-1'});

function callReadFromS3(name, callback){
    lambda.invoke(
        {
            FunctionName: 'readS3',
            Payload: JSON.stringify({"bucket":"cem.itesm.coding","key":name})
        }, 
        function(error, data) {
            if (error) {
                console.error(error);
                callback(0);
            }
            if(data.Payload){
                console.log(name + ":" + data.Payload);
                callback(parseInt(data.Payload));
            }
    });
}

exports.handler = (event, context, callback) => {

    
    callReadFromS3('number1', function(number1){
        callReadFromS3('number2',function(number2) {
            console.log("n1:" + number1);
            console.log("n2:" + number2);
            var result = number1 + number2;
            callback(null, {"result":result});
        });
    });
    

    
};